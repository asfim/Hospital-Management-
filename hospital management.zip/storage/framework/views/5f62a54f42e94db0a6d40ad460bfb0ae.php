<?php $__env->startSection('title', 'MediDiag – Advanced Diagnostic Care You Can Trust'); ?>

<?php $__env->startSection('content'); ?>


<?php if(!isset($hero) || (isset($hero) && $hero->status == 1)): ?>
<section class="hero-section" style="
    <?php if(!empty($hero->bg_image)): ?> 
        background-image: url('<?php echo e(asset('storage/' . $hero->bg_image)); ?>'); 
        background-size: cover; 
        background-position: center; 
    <?php endif; ?>
">
    <div class="hero-bg" style="
        <?php if(!empty($hero->bg_image) && !empty($hero->overlay_color)): ?> 
            background: <?php echo e($hero->overlay_color); ?>; 
        <?php endif; ?>
    ">
        <div class="container" style="position:relative; z-index:2;">
            <div class="row align-items-center g-5">
                <div class="col-lg-7" data-aos="fade-right" data-aos-duration="800">
                    
                    <div class="hero-badge mb-3">
                        <i class="bi bi-check-circle-fill text-success"></i>
                        Bangladesh's Most Trusted Diagnostic Network
                    </div>

                    
                    <h1 class="display-4 fw-bold text-white mb-3">
                        <?php echo nl2br(e($hero->title ?? "Advanced Care &\nPrecision Diagnostics\nYou Can Trust")); ?>

                    </h1>

                    <p class="text-white-50 mb-4" style="font-size:1.1rem; max-width:520px; line-height:1.8;">
                        <?php echo nl2br(e($hero->subtitle ?? "Expert consultants, state-of-the-art labs & compassionate care —\navailable 24/7 for you and your family.")); ?>

                    </p>

                    
                    <div class="hero-search mb-4">
                        <i class="bi bi-search text-muted fs-5 me-2 flex-shrink-0"></i>
                        <input type="text" class="form-control" placeholder="Search tests, packages, doctors…" id="heroSearchInput">
                        <button class="btn btn-primary fw-bold" onclick="window.location.href='<?php echo e(url('/tests')); ?>'">Search</button>
                    </div>

                    
                    <div class="d-flex flex-wrap gap-3 mb-4">
                        <a href="<?php echo e($hero->button_link ?? url('/appointment')); ?>" class="btn btn-light text-primary fw-bold px-4 py-2 rounded-pill shadow">
                            <i class="bi bi-calendar-check-fill me-2"></i><?php echo e($hero->button_text ?? 'Book Appointment'); ?>

                        </a>
                        <a href="<?php echo e(url('/packages')); ?>" class="btn btn-outline-light fw-bold px-4 py-2 rounded-pill">
                            <i class="bi bi-box-seam me-2"></i>View Packages
                        </a>
                    </div>

                    
                    <div class="hero-stats">
                        <div class="hero-stat">
                            <div class="stat-value"><?php echo e($stats['doctors'] ?? '50+'); ?></div>
                            <span class="stat-label">Expert Doctors</span>
                        </div>
                        <div class="hero-stat" style="border-left:1px solid rgba(255,255,255,.2); padding-left:2rem;">
                            <div class="stat-value"><?php echo e($stats['tests'] ?? '500+'); ?></div>
                            <span class="stat-label">Diagnostic Tests</span>
                        </div>
                        <div class="hero-stat" style="border-left:1px solid rgba(255,255,255,.2); padding-left:2rem;">
                            <div class="stat-value"><?php echo e($stats['patients'] ?? '100k+'); ?></div>
                            <span class="stat-label">Happy Patients</span>
                        </div>
                        <div class="hero-stat" style="border-left:1px solid rgba(255,255,255,.2); padding-left:2rem;">
                            <div class="stat-value"><?php echo e($stats['support'] ?? '24/7'); ?></div>
                            <span class="stat-label">Emergency Support</span>
                        </div>
                    </div>
                </div>

                <?php if(!empty($hero->image)): ?>
                <div class="col-lg-5 d-none d-lg-block" data-aos="fade-left" data-aos-duration="1000">
                    <img src="<?php echo e(asset('storage/' . $hero->image)); ?>" class="img-fluid rounded-4 shadow-lg" alt="Hero Image">
                </div>
                <?php else: ?>
                
                <div class="col-lg-5 d-none d-lg-block" data-aos="fade-left" data-aos-duration="1000" data-aos-delay="200">
                    <div class="bg-white bg-opacity-10 rounded-4 p-4 border border-white border-opacity-25" style="backdrop-filter:blur(12px);">
                        <h6 class="text-white fw-bold mb-3"><i class="bi bi-lightning-charge-fill text-warning me-2"></i>Quick Actions</h6>
                        <div class="d-flex flex-column gap-3">
                            <a href="<?php echo e(url('/appointment')); ?>" class="d-flex align-items-center gap-3 bg-white bg-opacity-10 rounded-3 p-3 text-white text-decoration-none" style="transition:all .3s; border:1px solid rgba(255,255,255,.15);" onmouseover="this.style.background='rgba(255,255,255,.2)'" onmouseout="this.style.background='rgba(255,255,255,.1)'">
                                <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center flex-shrink-0" style="width:44px;height:44px;">
                                    <i class="bi bi-calendar-check fs-5"></i>
                                </div>
                                <div>
                                    <div class="fw-bold" style="font-size:.95rem;">Book Appointment</div>
                                    <div style="font-size:.78rem; opacity:.7;">Schedule with our specialists</div>
                                </div>
                                <i class="bi bi-chevron-right ms-auto opacity-50"></i>
                            </a>
                            <a href="<?php echo e(url('/reports')); ?>" class="d-flex align-items-center gap-3 bg-white bg-opacity-10 rounded-3 p-3 text-white text-decoration-none" style="transition:all .3s; border:1px solid rgba(255,255,255,.15);" onmouseover="this.style.background='rgba(255,255,255,.2)'" onmouseout="this.style.background='rgba(255,255,255,.1)'">
                                <div class="bg-success rounded-circle d-flex align-items-center justify-content-center flex-shrink-0" style="width:44px;height:44px;">
                                    <i class="bi bi-file-earmark-medical fs-5"></i>
                                </div>
                                <div>
                                    <div class="fw-bold" style="font-size:.95rem;">Download Report</div>
                                    <div style="font-size:.78rem; opacity:.7;">Access results securely online</div>
                                </div>
                                <i class="bi bi-chevron-right ms-auto opacity-50"></i>
                            </a>
                            <a href="<?php echo e(url('/home-collection')); ?>" class="d-flex align-items-center gap-3 bg-white bg-opacity-10 rounded-3 p-3 text-white text-decoration-none" style="transition:all .3s; border:1px solid rgba(255,255,255,.15);" onmouseover="this.style.background='rgba(255,255,255,.2)'" onmouseout="this.style.background='rgba(255,255,255,.1)'">
                                <div class="bg-warning rounded-circle d-flex align-items-center justify-content-center flex-shrink-0" style="width:44px;height:44px;">
                                    <i class="bi bi-truck fs-5 text-dark"></i>
                                </div>
                                <div>
                                    <div class="fw-bold" style="font-size:.95rem;">Home Collection</div>
                                    <div style="font-size:.78rem; opacity:.7;">Sample pickup at your doorstep</div>
                                </div>
                                <i class="bi bi-chevron-right ms-auto opacity-50"></i>
                            </a>
                        </div>
                        <div class="mt-3 pt-3 border-top border-white border-opacity-15 text-center">
                            <small class="text-white-50"><i class="bi bi-lock-fill me-1 text-success"></i>Your data is safe & encrypted</small>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

    
    <div class="quick-actions">
        <div class="container">
            <div class="row g-4">
                <?php $__currentLoopData = $quickActions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 <?php echo e($index == 2 ? 'mx-auto' : ''); ?>" data-aos="fade-up" data-aos-delay="<?php echo e(($index + 1) * 100); ?>">
                    <div class="quick-card">
                        <div class="q-icon bg-<?php echo e($action['color'] ?? 'primary'); ?> bg-opacity-10 text-<?php echo e($action['color'] ?? 'primary'); ?> mx-auto">
                            <i class="bi <?php echo e($action['icon'] ?? 'bi-star'); ?>"></i>
                        </div>
                        <h4 class="fw-bold"><?php echo e($action['title'] ?? ''); ?></h4>
                        <p><?php echo e($action['description'] ?? ''); ?></p>
                        <a href="<?php echo e($action['link'] ?? '#'); ?>" class="text-<?php echo e($action['color'] ?? 'primary'); ?>"><?php echo e($action['button_text'] ?? 'View More'); ?> <i class="bi bi-arrow-right"></i></a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>


<section class="section-padding bg-white" style="padding-top: 120px;">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-6" data-aos="fade-right">
                <div class="position-relative">
                    <img src="<?php echo e(!empty($about['image']) ? asset('storage/' . $about['image']) : 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&w=800&q=80'); ?>"
                         alt="<?php echo e($about['title'] ?? 'About MediDiag'); ?>" class="img-fluid rounded-4 shadow-lg w-100" style="object-fit:cover; max-height:440px;">
                    <div class="position-absolute bottom-0 start-0 bg-primary text-white p-4 rounded-4 shadow-lg m-3">
                        <div class="d-flex align-items-center gap-3">
                            <span class="display-6 fw-bold"><?php echo e($about['years_number'] ?? '15+'); ?></span>
                            <span class="fw-semibold lh-sm"><?php echo nl2br(e($about['years_text'] ?? "Years of\nExcellence")); ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6" data-aos="fade-left">
                <div class="section-header mb-4">
                    <span class="label"><?php echo e($about['label'] ?? 'About MediDiag'); ?></span>
                    <h2><?php echo e($about['title'] ?? 'Leading the Way in Medical Diagnostics'); ?></h2>
                    <p class="mt-3"><?php echo e($about['description'] ?? ''); ?></p>
                </div>
                <div class="row g-3 mb-4">
                    <?php if(!empty($about['features']) && is_array($about['features'])): ?>
                        <?php $__currentLoopData = $about['features']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!empty($feature)): ?>
                        <div class="col-6">
                            <div class="d-flex align-items-center gap-2">
                                <i class="bi bi-check-circle-fill text-success fs-5"></i>
                                <span class="fw-semibold"><?php echo e($feature); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                
                <div class="row g-3 mb-4 text-center">
                    <div class="col-4 py-3 bg-light-soft rounded-3">
                        <h3 class="fw-bold text-primary mb-0"><?php echo e($stats['doctors'] ?? '50+'); ?></h3>
                        <small class="text-muted">Doctors</small>
                    </div>
                    <div class="col-4 py-3 bg-light-soft rounded-3">
                        <h3 class="fw-bold text-primary mb-0"><?php echo e($stats['patients'] ?? '100k+'); ?></h3>
                        <small class="text-muted">Patients</small>
                    </div>
                    <div class="col-4 py-3 bg-light-soft rounded-3">
                        <h3 class="fw-bold text-primary mb-0"><?php echo e($stats['tests'] ?? '500+'); ?></h3>
                        <small class="text-muted">Tests</small>
                    </div>
                </div>
                <a href="<?php echo e($about['button_link'] ?? url('/about')); ?>" class="btn btn-primary rounded-pill px-4"><?php echo e($about['button_text'] ?? 'Learn More'); ?> <i class="bi bi-arrow-right ms-1"></i></a>
            </div>
        </div>
    </div>
</section>


<section class="section-padding bg-light-soft">
    <div class="container">
        <div class="section-header centered mb-5" data-aos="fade-up">
            <span class="label">Diagnostics</span>
            <h2>Popular Diagnostic Tests</h2>
            <p class="mt-2">Explore our most requested tests. We ensure precise and timely results.</p>
        </div>

            <div class="row g-4 justify-content-center">
            <?php $__currentLoopData = $tests->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="<?php echo e(($i+1)*80); ?>">
                <div class="test-card-premium h-100 d-flex flex-column" style="cursor: pointer;" onclick="window.location.href='<?php echo e(url('/tests/'.$test->id)); ?>'">
                    <div class="t-icon bg-primary bg-opacity-10 text-primary mx-auto mb-3" style="width: 50px; height: 50px; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                        <i class="bi bi-activity fs-4"></i>
                    </div>
                    <div class="test-card-body p-4 text-center flex-grow-1">
                        <h5 class="fw-bold"><a href="<?php echo e(url('/tests/'.$test->id)); ?>" class="text-dark text-decoration-none"><?php echo e($test->name); ?></a></h5>
                        <p class="text-muted text-truncate mb-0"><?php echo e($test->description ?? 'Accurate and reliable diagnostic test.'); ?></p>
                    </div>
                    <div class="test-card-footer bg-light-soft border-top p-3 d-flex justify-content-between align-items-center">
                        <span class="price fw-bold text-primary fs-5">৳ <?php echo e(number_format($test->price, 0)); ?></span>
                        <div class="d-flex gap-2">
                            <a href="<?php echo e(url('/tests/'.$test->id)); ?>" class="btn btn-sm btn-outline-secondary rounded-pill px-3">Details</a>
                            <a href="<?php echo e(url('/appointment')); ?>?test=<?php echo e($test->id); ?>" class="btn btn-sm btn-primary rounded-pill px-4">Book</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div class="text-center mt-5" data-aos="fade-up">
            <a href="<?php echo e(url('/tests')); ?>" class="btn btn-outline-primary rounded-pill px-5">View All Tests</a>
        </div>
    </div>
</section>



<section class="section-padding bg-light-soft">
    <div class="container">
        <div class="section-header centered mb-5" data-aos="fade-up">
            <span class="label">Specialties</span>
            <h2>Our Departments</h2>
        </div>

        <div class="row g-4">
            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-4 col-sm-6" data-aos="zoom-in" data-aos-delay="<?php echo e(($i+1)*60); ?>">
                <a href="<?php echo e(url('/departments/' . ($dept->slug ?? ''))); ?>" class="text-decoration-none">
                    <div class="dept-card-premium h-100 p-4 text-center">
                        <div class="dept-icon-wrapper mx-auto mb-3">
                            <i class="bi <?php echo e($dept->icon ?? 'bi-heart-pulse'); ?> text-primary"></i>
                        </div>
                        <h5 class="fw-bold text-dark mb-2"><?php echo e($dept->name); ?></h5>
                        <div class="d-flex justify-content-center gap-3 mt-3 opacity-75">
                            <div class="text-muted small">
                                <i class="bi bi-person-fill text-primary"></i> <?php echo e($dept->doctors_count); ?> Doctors
                            </div>
                            <div class="text-muted small">
                                <i class="bi bi-clipboard2-pulse text-success"></i> <?php echo e($dept->tests_count); ?> Tests
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>


<section class="section-padding bg-white">
    <div class="container">
        <div class="d-flex justify-content-between align-items-end mb-5 flex-wrap gap-3" data-aos="fade-up">
            <div class="section-header mb-0">
                <span class="label">Medical Team</span>
                <h2 class="mb-0">Our Expert Doctors</h2>
            </div>
            <a href="<?php echo e(url('/doctors')); ?>" class="btn btn-outline-primary rounded-pill">View All Doctors</a>
        </div>

        <div class="row g-4">
            <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="<?php echo e(($i+1)*100); ?>">
                <div class="doctor-card-premium h-100">
                    <div class="doc-img-wrapper">
                        <img src="<?php echo e($doc->photo ? asset('storage/'.$doc->photo) : 'https://images.unsplash.com/photo-1594824436998-058a23116fc7?auto=format&fit=crop&w=500&q=80'); ?>" alt="<?php echo e($doc->name); ?>" class="img-fluid w-100">
                    </div>
                    <div class="doc-body p-4 text-center">
                        <h5 class="fw-bold mb-1"><?php echo e($doc->name); ?></h5>
                        <p class="specialty text-primary fw-semibold mb-2">
                            <i class="bi bi-heart-pulse-fill me-1"></i><?php echo e($doc->department ? $doc->department->name : 'Specialist'); ?>

                        </p>
                        <p class="degree small text-muted mb-3"><?php echo e($doc->specialization); ?></p>
                        
                        <div class="d-flex justify-content-center gap-3 mb-3 border-top pt-3 opacity-75">
                            <?php if(!empty($doc->experience_years) && $doc->experience_years > 0): ?>
                            <div class="text-muted small" title="Experience">
                                <i class="bi bi-briefcase-fill text-primary"></i> <?php echo e($doc->experience_years); ?> Yrs
                            </div>
                            <?php endif; ?>
                            <div class="text-muted small" title="Fee">
                                <i class="bi bi-cash-coin text-success"></i> ৳<?php echo e($doc->consultation_fee ?? 0); ?>

                            </div>
                        </div>

                        <div class="d-flex gap-2 justify-content-center">
                            <a href="<?php echo e(url('/appointment')); ?>?doctor=<?php echo e($doc->id); ?>" class="btn btn-primary rounded-pill px-4 w-100 fw-bold">Book Now</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>


<section class="section-padding bg-light-soft">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-6 order-lg-2" data-aos="fade-left">
                <img src="<?php echo e(!empty($whyChoose['image']) ? asset('storage/' . $whyChoose['image']) : 'https://images.unsplash.com/photo-1581594693702-fbdc51b2763b?auto=format&fit=crop&w=800&q=80'); ?>"
                     alt="Laboratory" class="img-fluid rounded-4 shadow-lg w-100" style="object-fit:cover; max-height:440px;">
            </div>
            <div class="col-lg-6 order-lg-1" data-aos="fade-right">
                <div class="section-header mb-4">
                    <span class="label"><?php echo e($whyChoose['label'] ?? 'Why Choose Us'); ?></span>
                    <h2><?php echo e($whyChoose['title'] ?? 'The MediDiag Difference'); ?></h2>
                    <p class="mt-2"><?php echo e($whyChoose['description'] ?? ''); ?></p>
                </div>

                <?php if(!empty($whyChoose['features']) && is_array($whyChoose['features'])): ?>
                <?php $__currentLoopData = $whyChoose['features']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="d-flex gap-3 mb-4">
                    <div class="icon-box bg-<?php echo e($f['color'] ?? 'primary'); ?> bg-opacity-10 text-<?php echo e($f['color'] ?? 'primary'); ?> rounded-3 flex-shrink-0" style="width:54px;height:54px;">
                        <i class="bi <?php echo e($f['icon'] ?? 'bi-check-circle'); ?> fs-4"></i>
                    </div>
                    <div>
                        <h5 class="fw-bold mb-1"><?php echo $f['title'] ?? ''; ?></h5>
                        <p class="text-muted mb-0 small"><?php echo e($f['desc'] ?? ''); ?></p>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>


<section class="section-padding bg-white">
    <div class="container text-center">
        <div class="section-header centered mb-5" data-aos="fade-up">
            <span class="label"><?php echo e($howItWorks['label'] ?? 'Process'); ?></span>
            <h2><?php echo e($howItWorks['title'] ?? 'How It Works'); ?></h2>
        </div>

        <div class="row g-4 position-relative">
            
            <div class="d-none d-lg-block position-absolute top-0 start-0 w-100" style="top:40px!important;z-index:1;">
                <div class="border-top border-2 border-primary" style="margin: 0 10%; opacity:.2;"></div>
            </div>

            <?php if(!empty($howItWorks['steps']) && is_array($howItWorks['steps'])): ?>
            <?php $__currentLoopData = $howItWorks['steps']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-6 position-relative" style="z-index:2;" data-aos="fade-up" data-aos-delay="<?php echo e(($i+1)*100); ?>">
                <div class="step-circle mx-auto"><?php echo e($step['n']); ?></div>
                <div class="icon-box bg-primary bg-opacity-10 text-primary rounded-circle mx-auto mb-3" style="width:56px;height:56px;">
                    <i class="bi <?php echo e($step['icon']); ?> fs-4"></i>
                </div>
                <h5 class="fw-bold mb-2"><?php echo e($step['title']); ?></h5>
                <p class="text-muted small mb-0"><?php echo e($step['desc']); ?></p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
</section>


<section class="section-padding bg-primary">
    <div class="container">
        <div class="section-header centered text-white mb-5" data-aos="fade-up">
            <span class="label" style="color:rgba(255,255,255,.6);">Patient Reviews</span>
            <h2 style="color:#fff;">What Our Patients Say</h2>
        </div>

        <?php if($testimonials->isNotEmpty()): ?>
        <div class="testimonial-marquee" aria-label="Patient reviews">
            <div class="testimonial-track">
                <?php $__currentLoopData = $testimonials->concat($testimonials); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="testimonial-slide">
                <div class="testimonial-card">
                    <i class="bi bi-quote quote-icon"></i>
                    <div class="stars mb-2">
                        <?php for($star = 1; $star <= 5; $star++): ?>
                            <i class="bi <?php echo e($star <= $testimonial->rating ? 'bi-star-fill' : 'bi-star'); ?>"></i>
                        <?php endfor; ?>
                    </div>
                    <p>&ldquo;<?php echo e($testimonial->review); ?>&rdquo;</p>
                    <div class="avatar d-flex align-items-center gap-3">
                        <?php if($testimonial->photo): ?>
                            <img src="<?php echo e(asset('storage/' . $testimonial->photo)); ?>" alt="<?php echo e($testimonial->name); ?>">
                        <?php else: ?>
                            <span class="testimonial-avatar-fallback"><?php echo e(strtoupper(substr($testimonial->name, 0, 1))); ?></span>
                        <?php endif; ?>
                        <div>
                            <h6 class="mb-0"><?php echo e($testimonial->name); ?></h6>
                            <small><?php echo e($testimonial->location); ?></small>
                        </div>
                    </div>
                </div>
            </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</section>


<section class="section-padding bg-light-soft">
    <div class="container">
        <div class="d-flex justify-content-between align-items-end mb-5 flex-wrap gap-3" data-aos="fade-up">
            <div class="section-header mb-0">
                <span class="label">Health Articles</span>
                <h2 class="mb-0">Latest Medical News</h2>
            </div>
            <a href="<?php echo e(url('/blog')); ?>" class="btn btn-outline-primary rounded-pill">Read All Articles</a>
        </div>

        <?php if($blogs->isNotEmpty()): ?>
        <div class="row g-4">
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="<?php echo e(($i+1)*100); ?>">
                <div class="blog-card">
                    <div class="overflow-hidden">
                        <?php if($blog->image): ?>
                            <img src="<?php echo e(asset('storage/' . $blog->image)); ?>" alt="<?php echo e($blog->title); ?>">
                        <?php else: ?>
                            <div class="d-flex align-items-center justify-content-center bg-primary bg-opacity-10 text-primary" style="height:210px;"><i class="bi bi-newspaper fs-1"></i></div>
                        <?php endif; ?>
                    </div>
                    <div class="blog-body">
                        <div class="blog-meta d-flex gap-3">
                            <span><i class="bi bi-tag-fill"></i> <?php echo e($blog->category); ?></span>
                            <span><i class="bi bi-calendar3"></i> <?php echo e($blog->published_at?->format('M d, Y')); ?></span>
                        </div>
                        <h5 class="fw-bold mb-2"><a href="<?php echo e(route('frontend.blog.show', $blog)); ?>"><?php echo e($blog->title); ?></a></h5>
                        <p class="mb-3"><?php echo e($blog->excerpt); ?></p>
                        <a href="<?php echo e(route('frontend.blog.show', $blog)); ?>" class="text-primary fw-bold text-decoration-none">Read More <i class="bi bi-arrow-right"></i></a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
    </div>
</section>


<?php
    $waNumber = \App\Models\Setting::get('site_whatsapp', '8801711000000');
?>
<a href="https://wa.me/<?php echo e(preg_replace('/[^0-9]/', '', $waNumber)); ?>" class="btn-whatsapp" title="Chat on WhatsApp" target="_blank">
    <i class="bi bi-whatsapp"></i>
</a>


<div class="mobile-bottom-bar">
    <a href="<?php echo e(url('/appointment')); ?>" class="btn btn-primary rounded-pill">
        <i class="bi bi-calendar-check me-1"></i> Book Appointment
    </a>
    <a href="<?php echo e(url('/reports')); ?>" class="btn btn-outline-primary rounded-pill">
        <i class="bi bi-file-medical me-1"></i> Reports
    </a>
</div>

<?php $__env->startPush('styles'); ?>
<style>
/* Premium Card Styles for Homepage */
.quick-card {
    background: #ffffff !important;
    border: 1px solid #e2e8f0 !important;
    border-radius: 1.25rem !important;
    box-shadow: 0 10px 30px rgba(15, 23, 42, 0.08) !important;
    padding: 2.25rem 1.75rem !important;
    text-align: center !important;
    transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1) !important;
    height: 100% !important;
    position: relative !important;
    overflow: hidden !important;
}
.quick-card:hover {
    transform: translateY(-8px) !important;
    box-shadow: 0 20px 45px rgba(37, 99, 235, 0.18) !important;
    border-color: #2563eb !important;
}
.quick-card::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 4px;
    background: linear-gradient(90deg, #2563eb, #06b6d4);
    opacity: 0;
    transition: opacity 0.3s ease;
}
.quick-card:hover::before {
    opacity: 1;
}

.test-card-premium {
    background: #ffffff !important;
    border: 1px solid #e2e8f0 !important;
    border-radius: 1.25rem !important;
    transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1) !important;
    position: relative !important;
    overflow: hidden !important;
    box-shadow: 0 10px 30px rgba(15, 23, 42, 0.06) !important;
}
.test-card-premium:hover {
    transform: translateY(-8px) !important;
    box-shadow: 0 22px 45px rgba(37, 99, 235, 0.16) !important;
    border-color: #2563eb !important;
}
.test-card-premium::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 4px;
    background: linear-gradient(90deg, #2563eb, #00b4d8);
    opacity: 0;
    transition: opacity 0.3s ease;
}
.test-card-premium:hover::before {
    opacity: 1;
}

.dept-card-premium {
    background: #ffffff !important;
    border-radius: 1.25rem !important;
    box-shadow: 0 10px 30px rgba(15, 23, 42, 0.06) !important;
    border: 1px solid #e2e8f0 !important;
    transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1) !important;
    position: relative !important;
    overflow: hidden !important;
}
.dept-card-premium:hover {
    transform: translateY(-8px) !important;
    box-shadow: 0 20px 40px rgba(37, 99, 235, 0.15) !important;
    border-color: #2563eb !important;
}
.dept-card-premium::before {
    content: '';
    position: absolute;
    bottom: 0; left: 0; right: 0;
    height: 4px;
    background: linear-gradient(90deg, #2563eb, #3b82f6);
    transform: scaleX(0);
    transform-origin: center;
    transition: transform 0.35s ease;
}
.dept-card-premium:hover::before {
    transform: scaleX(1);
}
.dept-icon-wrapper {
    width: 64px;
    height: 64px;
    border-radius: 50%;
    background: rgba(37, 99, 235, 0.08);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.8rem;
    transition: all 0.3s ease;
}
.dept-card-premium:hover .dept-icon-wrapper {
    background: #2563eb;
    color: #ffffff !important;
}
.dept-card-premium:hover .dept-icon-wrapper i {
    color: #ffffff !important;
}

.doctor-card-premium {
    background: #ffffff !important;
    border-radius: 1.25rem !important;
    box-shadow: 0 10px 30px rgba(15, 23, 42, 0.06) !important;
    border: 1px solid #e2e8f0 !important;
    transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1) !important;
    overflow: hidden !important;
    display: flex !important;
    flex-direction: column !important;
}
.doctor-card-premium:hover {
    transform: translateY(-8px) !important;
    box-shadow: 0 22px 45px rgba(37, 99, 235, 0.16) !important;
    border-color: #2563eb !important;
}
.doc-img-wrapper {
    position: relative;
    overflow: hidden;
    height: 240px;
}
.doc-img-wrapper img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: top;
    transition: transform 0.5s ease;
}
.doctor-card-premium:hover .doc-img-wrapper img {
    transform: scale(1.05);
}
.doctor-card-premium .doc-body {
    flex-grow: 1;
    display: flex;
    flex-direction: column;
}

.blog-card {
    background: #ffffff !important;
    border-radius: 1.25rem !important;
    box-shadow: 0 10px 30px rgba(15, 23, 42, 0.06) !important;
    border: 1px solid #e2e8f0 !important;
    transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1) !important;
    overflow: hidden !important;
    height: 100% !important;
}
.blog-card:hover {
    transform: translateY(-8px) !important;
    box-shadow: 0 22px 45px rgba(37, 99, 235, 0.16) !important;
    border-color: #2563eb !important;
}

.testimonial-card {
    background: #ffffff !important;
    border-radius: 1.25rem !important;
    box-shadow: 0 12px 35px rgba(0, 0, 0, 0.1) !important;
    border: 1px solid #e2e8f0 !important;
    transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1) !important;
}
.testimonial-card:hover {
    transform: translateY(-5px) !important;
    box-shadow: 0 20px 45px rgba(0, 0, 0, 0.18) !important;
    border-color: #2563eb !important;
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Diagnostic\resources\views/frontend/home.blade.php ENDPATH**/ ?>