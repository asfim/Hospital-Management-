<!-- CTA Banner -->
<section class="py-5 bg-primary text-white text-center">
    <div class="container">
        <h2 class="fw-bold mb-3" data-aos="fade-up"><?php echo e($footerSettings['cta_title']); ?></h2>
        <p class="lead mb-4" data-aos="fade-up" data-aos-delay="100"><?php echo e($footerSettings['cta_description']); ?></p>
        <a href="<?php echo e($footerSettings['cta_button_link']); ?>" class="btn btn-light btn-lg px-5 rounded-pill text-primary fw-bold" data-aos="zoom-in" data-aos-delay="200">
            <?php echo e($footerSettings['cta_button_text']); ?>

        </a>
    </div>
</section>

<!-- Footer -->
<footer class="main-footer">
    <div class="container">
        <div class="row">
            <!-- Brand Info -->
            <div class="col-lg-4 col-md-6 mb-4 pe-lg-5">
                <a class="d-flex align-items-center text-decoration-none mb-3" href="<?php echo e(url('/')); ?>">
                    <?php if(!empty($siteSettings['site_logo'])): ?>
                        <img src="<?php echo e(asset('storage/' . $siteSettings['site_logo'])); ?>" alt="<?php echo e($siteSettings['site_name'] ?? 'MediDiag'); ?>" style="height: 60px;" class="me-2">
                    <?php else: ?>
                        <i class="bi bi-heart-pulse-fill text-secondary fs-2 me-2"></i>
                    <?php endif; ?>
                </a>
                <p class="mb-4"><?php echo e($footerSettings['description']); ?></p>
                <div class="d-flex gap-3">
                    <?php $__currentLoopData = $footerSettings['socials']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!empty($social['url'])): ?><a href="<?php echo e($social['url']); ?>" class="text-white fs-5" target="_blank" rel="noopener" title="<?php echo e($social['name']); ?>"><i class="bi <?php echo e($social['icon']); ?>"></i></a><?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- Quick Links -->
            <div class="col-lg-2 col-md-6 mb-4">
                <h5>Quick Links</h5>
                <ul class="footer-links">
                    <?php $__currentLoopData = $footerSettings['quick_links']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><a href="<?php echo e($link['url']); ?>"><?php echo e($link['label']); ?></a></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <!-- Services -->
            <div class="col-lg-3 col-md-6 mb-4">
                <h5>Our Services</h5>
                <ul class="footer-links">
                    <?php $__currentLoopData = $footerSettings['service_links']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><a href="<?php echo e($link['url']); ?>"><?php echo e($link['label']); ?></a></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <!-- Contact & Newsletter -->
            <div class="col-lg-3 col-md-6 mb-4">
                <h5>Contact Info</h5>
                <ul class="footer-links mb-4">
                    <li class="text-white"><i class="bi bi-geo-alt-fill text-secondary me-2"></i> <?php echo e($siteSettings['site_address']); ?></li>
                    <li class="text-white"><i class="bi bi-telephone-fill text-secondary me-2"></i> <?php echo e($siteSettings['site_phone']); ?></li>
                    <li class="text-white"><i class="bi bi-envelope-fill text-secondary me-2"></i> <?php echo e($siteSettings['site_email']); ?></li>
                </ul>
                
                <h6 class="text-white mb-2">Subscribe to Newsletter</h6>
                <form class="d-flex">
                    <input type="email" class="form-control rounded-start-pill border-0" placeholder="Email Address" required>
                    <button class="btn btn-secondary rounded-end-pill px-3" type="submit"><i class="bi bi-send-fill"></i></button>
                </form>
            </div>
        </div>
    </div>
    
    <div class="footer-bottom text-center">
        <div class="container">
            <p class="mb-0">&copy; <?php echo e(date('Y')); ?> <?php echo e($siteSettings['site_name'] ?? 'MediDiag'); ?> Diagnostic Center. All Rights Reserved.</p>
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\Diagnostic\resources\views/components/frontend/footer.blade.php ENDPATH**/ ?>